
// 'use strict';

const express = require('express');
const socketIO = require('socket.io');
const path = require('path');
var stat = require('node-static');

// build server, listen, and serve necessary files in directory 

// var io = socketIO.listen(app);
var file = new stat.Server(path.join(__dirname, 'public'));

function handler(req, res) {
    file.serve(req, res);
}

const PORT = process.env.PORT || 5000;
const INDEX = path.join(__dirname, 'public/index-ev.html');


const server = express()
  .use((req, res) => res.sendFile(INDEX) )

  .listen(PORT, () => console.log(`Listening on ${ PORT }`));

const io = socketIO(server);


io.on('connection', (socket) => {
  console.log('Client connected');
  socket.on('disconnect', () => console.log('Client disconnected'));
  socket.on('width', function(data) {
        io.emit('width', data);
    });
    socket.on('user image', function (msg) {
        socket.broadcast.emit('user image', msg);
    });
    socket.on('tap', function(location) {
        io.emit('tap', location);
    });
});

setInterval(() => io.emit('time', new Date().toTimeString()), 1000);





